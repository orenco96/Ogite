<div class="images">
    <img src="./images/gwada/img1.jpg">
    <img src="./images/gwada/img2.jpg">
    <img src="./images/gwada/img3.jpg">
    <img src="./images/gwada/img4.jpg">
    <img src="./images/gwada/img5.jpg">
    <img src="./images/gwada/img1.jpg">
</div>